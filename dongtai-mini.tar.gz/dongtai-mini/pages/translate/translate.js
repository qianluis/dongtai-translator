// pages/translate/translate.js
const translator = require('../../utils/translator.js');

const recorderManager = wx.getRecorderManager();
const innerAudioContext = wx.createInnerAudioContext();

Page({
  data: {
    inputText: '',
    outputText: '',
    direction: 'pt2dt', // pt2dt: 普通话→东台话, dt2pt: 东台话→普通话
    directionLabel: '普通话 → 东台话',
    isRecording: false,
    isPlaying: false,
    isTranslating: false,
    hasResult: false,
    showClearBtn: false,
    swapAnimation: false,
  },

  onLoad() {
    // 录音结束回调
    recorderManager.onStop((res) => {
      this.setData({ isRecording: false });
      // 微信小程序语音识别需要调用插件或云函数
      // 这里使用语音识别插件的方式提示用户
      wx.showModal({
        title: '语音输入',
        content: '语音识别功能需要接入微信同声传译插件。当前已录制音频，可手动输入文字进行翻译。',
        showCancel: false,
        confirmText: '知道了',
        confirmColor: '#E8532E'
      });
    });

    recorderManager.onError(() => {
      this.setData({ isRecording: false });
      wx.showToast({ title: '录音失败', icon: 'none' });
    });

    // 音频播放结束回调
    innerAudioContext.onEnded(() => {
      this.setData({ isPlaying: false });
    });

    innerAudioContext.onError(() => {
      this.setData({ isPlaying: false });
      wx.showToast({ title: '播放失败', icon: 'none' });
    });
  },

  onUnload() {
    innerAudioContext.destroy();
  },

  // 输入文字
  onInput(e) {
    const inputText = e.detail.value;
    this.setData({
      inputText,
      showClearBtn: inputText.length > 0
    });
  },

  // 清空输入
  onClear() {
    this.setData({
      inputText: '',
      outputText: '',
      hasResult: false,
      showClearBtn: false
    });
  },

  // 切换翻译方向
  onSwap() {
    const newDirection = this.data.direction === 'pt2dt' ? 'dt2pt' : 'pt2dt';
    this.setData({
      direction: newDirection,
      directionLabel: newDirection === 'pt2dt' ? '普通话 → 东台话' : '东台话 → 普通话',
      inputText: '',
      outputText: '',
      hasResult: false,
      showClearBtn: false,
      swapAnimation: true
    });
    setTimeout(() => this.setData({ swapAnimation: false }), 300);
  },

  // 翻译
  onTranslate() {
    const { inputText, direction } = this.data;
    if (!inputText.trim()) {
      wx.showToast({ title: '请输入要翻译的内容', icon: 'none' });
      return;
    }

    this.setData({ isTranslating: true });

    // 模拟短暂延迟以展示翻译动画
    setTimeout(() => {
      let outputText;
      if (direction === 'pt2dt') {
        outputText = translator.ptToDt(inputText);
      } else {
        outputText = translator.dtToPt(inputText);
      }

      this.setData({
        outputText,
        isTranslating: false,
        hasResult: true
      });

      // 保存历史
      translator.saveHistory(inputText, outputText, direction);
    }, 300);
  },

  // 语音输入
  onStartRecord() {
    if (this.data.isRecording) {
      recorderManager.stop();
      this.setData({ isRecording: false });
      return;
    }

    wx.authorize({
      scope: 'scope.record',
      success: () => {
        this.setData({ isRecording: true });
        recorderManager.start({
          format: 'mp3',
          duration: 60000,
          sampleRate: 16000,
          numberOfChannels: 1,
          encodeBitRate: 96000
        });
        // 最长录音60秒后自动停止
        setTimeout(() => {
          if (this.data.isRecording) {
            recorderManager.stop();
          }
        }, 60000);
      },
      fail: () => {
        wx.showModal({
          title: '需要录音权限',
          content: '请在设置中开启录音权限以使用语音输入功能',
          confirmText: '去设置',
          confirmColor: '#E8532E',
          success: (res) => {
            if (res.confirm) wx.openSetting();
          }
        });
      }
    });
  },

  onStopRecord() {
    recorderManager.stop();
    this.setData({ isRecording: false });
  },

  // 语音播报
  onSpeak() {
    const { outputText, isPlaying } = this.data;
    if (!outputText) return;

    if (isPlaying) {
      innerAudioContext.stop();
      this.setData({ isPlaying: false });
      return;
    }

    // 使用微信同声传译插件进行语音合成
    // 此处先使用系统提示
    wx.showActionSheet({
      itemList: ['使用系统朗读', '复制文本到剪贴板'],
      itemColor: '#333333',
      success: (res) => {
        if (res.tapIndex === 0) {
          // 微信小程序暂无原生TTS，提示用户
          wx.showToast({ title: '语音合成需接入插件', icon: 'none' });
        } else if (res.tapIndex === 1) {
          this.onCopy();
        }
      }
    });
  },

  // 复制结果
  onCopy() {
    const { outputText } = this.data;
    if (!outputText) return;
    wx.setClipboardData({
      data: outputText,
      success: () => {
        wx.showToast({ title: '已复制到剪贴板', icon: 'success' });
      }
    });
  },

  // 分享
  onShare() {
    const { inputText, outputText, directionLabel } = this.data;
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  // 使用示例
  onExample(e) {
    const example = e.currentTarget.dataset.text;
    this.setData({
      inputText: example,
      showClearBtn: true
    });
    this.onTranslate();
  }
});
