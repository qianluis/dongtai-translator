// pages/translate/translate.js
const translator = require('../../utils/translator.js');

// 微信同声传译插件
const plugin = requirePlugin('WechatSI');
const manager = plugin.getRecordRecognitionManager();

Page({
  data: {
    inputText: '',
    outputText: '',
    direction: 'pt2dt',
    directionLabel: '普通话 → 东台话',
    isRecording: false,
    isSpeaking: false,
    isTranslating: false,
    hasResult: false,
    showClearBtn: false,
    swapAnimation: false,
    statusText: '准备就绪',
  },

  onLoad() {
    this.initRecognition();
  },

  onUnload() {
    if (this.innerAudio) this.innerAudio.destroy();
  },

  // ===== 语音识别（微信同声传译插件）=====
  initRecognition() {
    if (!manager) {
      this.setData({ statusText: '⚠️ 语音识别插件未安装，请用文字输入' });
      return;
    }

    manager.onRecognize((res) => {
      // 实时识别结果
      const text = res.result;
      if (text) {
        this.setData({ inputText: text, showClearBtn: true, statusText: '识别中: ' + text });
      }
    });

    manager.onStop((res) => {
      // 识别结束
      this.setData({ isRecording: false });
      const text = res.result;
      if (text && text.trim()) {
        // 方言纠错
        let corrected = this.correctSpeech(text);
        this.setData({ inputText: corrected, showClearBtn: true });
        // 自动翻译！
        this.doTranslate(corrected);
      } else {
        this.setData({ statusText: '未识别到内容，请重试' });
      }
    });

    manager.onError((res) => {
      this.setData({ isRecording: false });
      if (res.retcode === -30003) {
        this.setData({ statusText: '❌ 录音权限被拒绝' });
      } else {
        this.setData({ statusText: '识别出错: ' + (res.errMsg || '未知错误') });
      }
    });

    manager.onStart(() => {
      this.setData({ isRecording: true, statusText: '🎙️ 正在听，请说话...' });
    });
  },

  // 方言语音纠错
  correctSpeech(text) {
    const fixes = {
      '什地':'什的','神的':'什的','甚的':'什的','十地':'什的',
      '哪快':'哪块','那块':'哪块','拉块':'哪块',
      '几点':'几钿','几钱':'几钿','几店':'几钿',
      '搞子':'杲昃','高子':'杲昃','稿子':'杲昃',
      '来死':'来斯','来四':'来斯','赖斯':'来斯',
      '腿板':'推板','退板':'推板',
      '我仇':'我俦','我凑':'我俦','我愁':'我俦','我抽':'我俦',
      '你仇':'你俦','你凑':'你俦','你抽':'你俦',
      '他仇':'他俦','他凑':'他俦','他抽':'他俦',
      '迭迭':'爹爹','跌跌':'爹爹',
      '牙儿':'伢儿','亚儿':'伢儿','牙人':'伢儿',
      '大雨':'汏浴','大浴':'汏浴','达宇':'汏浴',
      '下去':'家去','架去':'家去',
      '木得':'呒得','没得':'呒得','么得':'呒得',
      '今儿':'今呃','金额':'今呃',
      '明儿':'明呃','名额':'明呃',
      '昨儿':'昨呃','做额':'昨呃',
    };
    let result = text;
    for (const [w, r] of Object.entries(fixes)) {
      result = result.replace(new RegExp(w, 'g'), r);
    }
    return result;
  },

  // ===== 语音输入 =====
  onStartRecord() {
    if (this.data.isRecording) {
      manager && manager.stop();
      this.setData({ isRecording: false });
      return;
    }

    if (!manager) {
      // 降级：使用原生录音（无法识别文字）
      wx.showToast({ title: '请用文字输入，语音识别需安装插件', icon: 'none' });
      return;
    }

    manager.start({
      lang: 'zh_CN',
    });
  },

  // ===== 翻译 =====
  onTranslate() {
    this.doTranslate(this.data.inputText);
  },

  doTranslate(inputText) {
    if (!inputText || !inputText.trim()) {
      wx.showToast({ title: '请输入要翻译的内容', icon: 'none' });
      return;
    }

    this.setData({ isTranslating: true, statusText: '翻译中...' });

    setTimeout(() => {
      let outputText;
      if (this.data.direction === 'pt2dt') {
        outputText = translator.ptToDt(inputText);
      } else {
        outputText = translator.dtToPt(inputText);
      }

      this.setData({
        outputText,
        isTranslating: false,
        hasResult: true,
        statusText: '✅ 翻译完成',
      });

      // 自动朗读翻译结果
      this.speak(outputText);

      // 保存历史
      translator.saveHistory(inputText, outputText, this.data.direction);
    }, 100);
  },

  // ===== 语音播报（微信同声传译插件TTS）=====
  speak(text) {
    if (!text || !plugin) return;

    this.setData({ isSpeaking: true, statusText: '🔊 播报中...' });

    const url = plugin.translate({
      lfrom: 'zh_CN',
      lto: 'zh_CN',
      content: text,
      tts: true,
      success: (res) => {
        if (res.filename) {
          this.playAudio(res.filename);
        } else {
          this.setData({ isSpeaking: false, statusText: '播报完成' });
        }
      },
      fail: () => {
        // 降级：使用系统通知
        this.setData({ isSpeaking: false, statusText: '播报失败，请查看文字' });
      }
    });
  },

  playAudio(filePath) {
    if (!this.innerAudio) {
      this.innerAudio = wx.createInnerAudioContext();
      this.innerAudio.onEnded(() => {
        this.setData({ isSpeaking: false, statusText: '播报完成' });
      });
      this.innerAudio.onError(() => {
        this.setData({ isSpeaking: false, statusText: '播放失败' });
      });
    }
    this.innerAudio.src = filePath;
    this.innerAudio.play();
  },

  onStopSpeak() {
    if (this.innerAudio) {
      this.innerAudio.stop();
    }
    this.setData({ isSpeaking: false, statusText: '已停止播报' });
  },

  // ===== 其他 =====
  onInput(e) {
    const inputText = e.detail.value;
    this.setData({ inputText, showClearBtn: inputText.length > 0 });
  },

  onClear() {
    this.setData({ inputText: '', outputText: '', hasResult: false, showClearBtn: false });
  },

  onSwap() {
    const newDir = this.data.direction === 'pt2dt' ? 'dt2pt' : 'pt2dt';
    this.setData({
      direction: newDir,
      directionLabel: newDir === 'pt2dt' ? '普通话 → 东台话' : '东台话 → 普通话',
      inputText: '', outputText: '', hasResult: false, showClearBtn: false,
      swapAnimation: true
    });
    setTimeout(() => this.setData({ swapAnimation: false }), 300);
  },

  onCopy() {
    if (!this.data.outputText) return;
    wx.setClipboardData({
      data: this.data.outputText,
      success: () => wx.showToast({ title: '已复制', icon: 'success' })
    });
  },

  onExample(e) {
    const text = e.currentTarget.dataset.text;
    this.setData({ inputText: text, showClearBtn: true });
    this.doTranslate(text);
  },
});
