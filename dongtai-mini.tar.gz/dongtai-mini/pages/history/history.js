// pages/history/history.js
const translator = require('../../utils/translator.js');

Page({
  data: {
    historyList: [],
    isEmpty: false,
  },

  onShow() {
    this.loadHistory();
  },

  loadHistory() {
    const historyList = translator.getHistory();
    this.setData({
      historyList,
      isEmpty: historyList.length === 0
    });
  },

  // 点击历史记录 - 重新翻译
  onTapItem(e) {
    const item = e.currentTarget.dataset.item;
    wx.showActionSheet({
      itemList: [
        '复制输入',
        '复制翻译结果',
        '重新翻译',
        '删除此条记录'
      ],
      itemColor: '#333333',
      success: (res) => {
        if (res.tapIndex === 0) {
          wx.setClipboardData({ data: item.input });
        } else if (res.tapIndex === 1) {
          wx.setClipboardData({ data: item.output });
        } else if (res.tapIndex === 2) {
          // 切换到翻译页并填充
          wx.switchTab({
            url: '/pages/translate/translate'
          });
          // 通过eventChannel或全局变量传递
          getApp().globalData.retranslateInput = item.input;
          getApp().globalData.retranslateDirection = item.direction;
        } else if (res.tapIndex === 3) {
          this.onDeleteItem(e);
        }
      }
    });
  },

  // 删除单条记录
  onDeleteItem(e) {
    const id = e.currentTarget.dataset.item.id;
    wx.showModal({
      title: '删除记录',
      content: '确定要删除这条翻译记录吗？',
      confirmText: '删除',
      confirmColor: '#E8532E',
      cancelColor: '#999999',
      success: (res) => {
        if (res.confirm) {
          translator.deleteHistoryItem(id);
          this.loadHistory();
          wx.showToast({ title: '已删除', icon: 'success' });
        }
      }
    });
  },

  // 清空全部历史
  onClearAll() {
    if (this.data.isEmpty) return;

    wx.showModal({
      title: '清空历史',
      content: '确定要清空所有翻译记录吗？此操作不可恢复。',
      confirmText: '清空',
      confirmColor: '#E8532E',
      cancelColor: '#999999',
      success: (res) => {
        if (res.confirm) {
          translator.clearHistory();
          this.loadHistory();
          wx.showToast({ title: '已清空', icon: 'success' });
        }
      }
    });
  },

  // 长按删除
  onLongPressItem(e) {
    this.onDeleteItem(e);
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.loadHistory();
    wx.stopPullDownRefresh();
  }
});
