// pages/dict/dict.js
const translator = require('../../utils/translator.js');

Page({
  data: {
    categories: [],
    expandedIndex: -1,
    searchKeyword: '',
    searchResults: [],
    isSearching: false,
    showFavorites: false,
    favorites: [],
  },

  onLoad() {
    this.loadDictionary();
  },

  onShow() {
    // 刷新收藏状态
    this.loadDictionary();
    if (this.data.showFavorites) {
      this.loadFavorites();
    }
  },

  loadDictionary() {
    const categories = translator.getDictionary();
    // 为每个词条添加收藏状态
    const favorites = translator.getFavorites();
    for (const cat of categories) {
      for (const word of cat.words) {
        word.isFav = favorites.some(f => f.pt === word.pt && f.dt === word.dt);
      }
    }
    this.setData({ categories });
  },

  loadFavorites() {
    const favorites = translator.getFavorites();
    this.setData({ favorites });
  },

  // 展开/收起分类
  onToggleCategory(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      expandedIndex: this.data.expandedIndex === index ? -1 : index
    });
  },

  // 搜索
  onSearchInput(e) {
    const keyword = e.detail.value.trim();
    this.setData({ searchKeyword: keyword });

    if (keyword.length === 0) {
      this.setData({ searchResults: [], isSearching: false });
      return;
    }

    const results = translator.searchDictionary(keyword);
    // 添加收藏状态
    const favorites = translator.getFavorites();
    for (const word of results) {
      word.isFav = favorites.some(f => f.pt === word.pt && f.dt === word.dt);
    }
    this.setData({ searchResults: results, isSearching: true });
  },

  onClearSearch() {
    this.setData({ searchKeyword: '', searchResults: [], isSearching: false });
  },

  // 收藏/取消收藏
  onToggleFavorite(e) {
    const { pt, dt } = e.currentTarget.dataset;
    const isFav = translator.toggleFavorite({ pt, dt });

    wx.showToast({
      title: isFav ? '已收藏' : '取消收藏',
      icon: isFav ? '❤️' : '💔',
      duration: 1000
    });

    // 刷新界面
    this.loadDictionary();
    if (this.data.isSearching) {
      const keyword = this.data.searchKeyword;
      const results = translator.searchDictionary(keyword);
      const favorites = translator.getFavorites();
      for (const word of results) {
        word.isFav = favorites.some(f => f.pt === word.pt && f.dt === word.dt);
      }
      this.setData({ searchResults: results });
    }
    if (this.data.showFavorites) {
      this.loadFavorites();
    }
  },

  // 点击词条进入翻译
  onTapWord(e) {
    const { pt, dt } = e.currentTarget.dataset;
    wx.showActionSheet({
      itemList: [
        `翻译"${pt}"到东台话`,
        `翻译"${dt}"到普通话`,
        '复制普通话',
        '复制东台话'
      ],
      itemColor: '#333333',
      success: (res) => {
        if (res.tapIndex === 0) {
          wx.setClipboardData({ data: translator.ptToDt(pt) });
        } else if (res.tapIndex === 1) {
          wx.setClipboardData({ data: translator.dtToPt(dt) });
        } else if (res.tapIndex === 2) {
          wx.setClipboardData({ data: pt });
        } else if (res.tapIndex === 3) {
          wx.setClipboardData({ data: dt });
        }
      }
    });
  },

  // 切换收藏视图
  onToggleFavorites() {
    const show = !this.data.showFavorites;
    if (show) {
      this.loadFavorites();
    }
    this.setData({ showFavorites: show });
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.loadDictionary();
    if (this.data.showFavorites) {
      this.loadFavorites();
    }
    wx.stopPullDownRefresh();
  }
});
