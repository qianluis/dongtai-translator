// app.js
App({
  onLaunch() {
    // 初始化本地存储
    if (!wx.getStorageSync('translateHistory')) {
      wx.setStorageSync('translateHistory', []);
    }
    if (!wx.getStorageSync('dictFavorites')) {
      wx.setStorageSync('dictFavorites', []);
    }
  },
  globalData: {
    themeColor: '#E8532E',
    themeColorLight: '#FF7B54',
    themeColorBg: '#FFF5F2'
  }
});
